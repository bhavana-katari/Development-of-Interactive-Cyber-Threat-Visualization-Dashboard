# Network Scanner Architecture & Flow

## System Components

```
┌─────────────────────────────────────────────────────────────────┐
│                   CyberShield SOC Dashboard (Dash App)          │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Network Scanner Button                                 │    │
│  │  [🔍 Scan Network] ← User clicks this                   │    │
│  └──────────────────────────┬──────────────────────────────┘    │
│                             │                                     │
│  ┌──────────────────────────▼──────────────────────────────┐    │
│  │  Dash Callback: scan_network()                          │    │
│  │  - force_scan=True to bypass cache                      │    │
│  │  - Calls scanner.scan_network_arp()                     │    │
│  │  - Formats results into HTML table                      │    │
│  │  - Updates device statistics                            │    │
│  └──────────────────────────┬──────────────────────────────┘    │
│                             │                                     │
└─────────────────────────────┼─────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              RealNetworkScanner Class (network_scanner.py)      │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  scan_network_arp(force_scan=True)                      │    │
│  │  - Gets local IP: 192.168.31.29                         │    │
│  │  - Determines subnet: 192.168.31.0/24                   │    │
│  │  - Chooses scanning method                              │    │
│  └──────────────────────────┬──────────────────────────────┘    │
│                             │                                     │
│              ┌──────────────┴──────────────┐                     │
│              │                             │                     │
│    ┌─────────▼─────────┐      ┌──────────▼──────────┐           │
│    │  Method 1: ARP    │      │  Method 2: Fallback │           │
│    │  (if scapy avail) │      │  (socket/ping)      │           │
│    │                   │      │                     │           │
│    │ _scan_with_arp()  │      │ _scan_fallback()    │           │
│    └─────────┬─────────┘      └──────────┬──────────┘           │
│              │                           │                       │
│              └──────┬────────────────────┘                       │
│                     │                                            │
│       ┌─────────────▼──────────────┐                            │
│       │ _classify_devices()        │                            │
│       │ - Identify device type     │                            │
│       │ - Set online/suspicious    │                            │
│       │ - Resolve hostnames        │                            │
│       └─────────────┬──────────────┘                            │
│                     │                                            │
│       ┌─────────────▼──────────────┐                            │
│       │ get_open_ports()           │                            │
│       │ (Optional, multi-threaded) │                            │
│       └─────────────┬──────────────┘                            │
│                     │                                            │
│                     │                                            │
└─────────────────────┼──────────────────────────────────────────┘
                      │
                      ▼
        ┌─────────────────────────────┐
        │   Return Device Array       │
        │   [{                        │
        │     'ip': '192.168.1.29',   │
        │     'mac': 'A4:C3:...',     │
        │     'hostname': 'Bhavana',  │
        │     'type': 'This Device',  │
        │     'status': 'Online'      │
        │   }, ...]                   │
        └─────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│              Dashboard UI - Display Results                      │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  ✅ Network scan completed successfully!                 │  │
│  │     Found X device(s)                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Detected Devices Table                                  │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ IP Address    MAC Address        Hostname   Type  Status │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ 192.168.1.29  A4:C3:F0:ED:C8:CA Bhavana    PC    Online │  │
│  │ 192.168.1.1   00:11:22:33:44:55 TP-Link    R.   Online │  │
│  │ 192.168.1.50  D4:E6:B7:AC:1F:2A iPhone12   Mob  Online │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Network Statistics                                      │  │
│  │  Total Devices: 3  | Suspicious: 0 | Ports: 12          │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

## Scanning Methods Comparison

### Method 1: ARP Scanning (Primary)
```
┌────────────────────────────────────────┐
│  Your Device                           │
│  (192.168.31.29)                       │
└──────────────────┬─────────────────────┘
                   │
                   │ ARP Broadcast
                   │ "Who is 192.168.31.1?"
                   │ "Who is 192.168.31.2?"
                   │ ... (all IPs in subnet)
                   ▼
        ┌──────────────────────┐
        │   Network Switch     │
        │   (Layer 2)          │
        └──────────────────────┘
         │    │    │    │    │
         ▼    ▼    ▼    ▼    ▼
      Router  PC  Phone  TV  Printer
      │       │   │      │   │
      └───────┴───┴──────┴───┘
              │
         ARP Replies
         "I'm 192.168.31.1 (MAC)"
         "I'm 192.168.31.50 (MAC)"
         
      Results Received in <5 seconds

Speed: Fast (5-15 seconds for 256 IPs)
Accuracy: Very High
Requirements: scapy library, OS support
```

### Method 2: Fallback Mode (Socket/Ping)
```
┌────────────────────────────────────────┐
│  Your Device                           │
│  (192.168.31.29)                       │
└──────────────────┬─────────────────────┘
                   │
    ┌──────────────┼──────────────┐
    │              │              │
    ▼              ▼              ▼
Try TCP 53    Try TCP 80    Try ICMP Ping
(DNS Port)    (HTTP)        (if available)
    │              │              │
    ▼              ▼              ▼
Connect to   Connect to   Send ping to
192.168.1.1  192.168.1.1  192.168.1.1
    
If any succeeds: Device is ONLINE
If all fail: Device is OFFLINE or blocked

Speed: Moderate (5-30 seconds)
Accuracy: Good for responsive devices
Requirements: None (always available)
```

## Data Flow for Single Device

```
Network Device Found: 192.168.31.1

┌─────────────────────────────────────┐
│  1. Get IP                          │
│     ip = "192.168.31.1"             │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│  2. Get MAC Address (if available)  │
│     mac = "00:11:22:33:44:55"       │
│     (or "Unknown" if not available) │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│  3. Resolve Hostname                │
│     hostname = _get_hostname()      │
│     - Try DNS reverse lookup        │
│     - Return "Unknown" if fails     │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│  4. Classify Device Type            │
│     type = _classify_devices()      │
│     Check:                          │
│     - IP pattern (.1 = Router)      │
│     - Hostname keywords             │
│     - Service detection             │
│     Result: "Router", "Computer"    │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│  5. Determine Status                │
│     status = _get_status()          │
│     - Responds to ping/ARP?         │
│     - Online or Offline             │
│     - Check for suspicious behavior │
└────────────────┬────────────────────┘
                 │
┌────────────────▼────────────────────┐
│  Final Device Object:               │
│  {                                  │
│    'ip': '192.168.31.1',           │
│    'mac': '00:11:22:33:44:55',    │
│    'hostname': 'TP-Link-Router',   │
│    'type': 'Router',               │
│    'status': 'Online'              │
│  }                                  │
└─────────────────────────────────────┘
```

## Background vs Click-Triggered Scanning

```
┌──────────────────────────────────────────────────────────┐
│         Regular Background Update                         │
│         (Every 5 seconds)                                │
├──────────────────────────────────────────────────────────┤
│                                                           │
│  scanner.scan_network_arp()  ← force_scan=False (default) │
│           │                                              │
│           ├─► Cache hit? Return cached list              │
│           │                                              │
│           └─► Cache miss? Run full scan                  │
│                                                           │
│  Updates global_data['real_network_data']                │
│  Minimal UI updates                                      │
│                                                           │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│      User Button Click - "Scan Network"                  │
│      (On-demand, user triggered)                         │
├──────────────────────────────────────────────────────────┤
│                                                           │
│  scanner.scan_network_arp(force_scan=True)  ← BYPASS! │
│           │                                              │
│           └─► Always run fresh scan                      │
│               Ignore cache                               │
│                                                           │
│  Updates:                                                │
│  - Devices table with fresh data                         │
│  - Device count                                          │
│  - Suspicious device count                               │
│  - Open ports                                            │
│  - Statistics                                            │
│                                                           │
│  Displays:                                               │
│  - Success/failure message                               │
│  - Complete device table                                 │
│  - All metrics                                           │
│                                                           │
└──────────────────────────────────────────────────────────┘
```

## Cache Management

```
                    ┌──────────────────┐
                    │  Scan Requested  │
                    └────────┬─────────┘
                             │
                ┌────────────▼────────────┐
                │ Check Current Cache     │
                │ & Timestamp             │
                └────────────┬────────────┘
                             │
                    ┌────────▼────────┐
                    │  force_scan?    │
                    └───┬──────────┬──┘
                        │          │
                    YES │          │ NO
                        │          │
        ┌───────────────▼┐      ┌─▼────────────┐
        │ Ignore Cache   │      │Check Age     │
        │ Run Fresh Scan │      │(30 sec TTL)  │
        └────────┬───────┘      └─┬────────────┘
                 │                │
                 │            ┌───▼────────┐
                 │            │ Cache      │
                 │            │ Fresh?     │
                 │            └─┬────┬─────┘
                 │              │    │
                 │          YES │    │ NO
                 │              │    │
                 │          ┌───▼┐  │
                 │          │Use │  │
                 │          │    │  │
                 │          │Cache│  │
                 │          │    │  │
                 │          │List│  │
                 │          └────┘  │
                 │              │    │
                 │  ┌───────────┘    │
                 │  │                │
                 │  ▼                │
        ┌────────▼────────┐    ┌─────▼──────┐
        │   Full Scan     │    │ Update     │
        │   (5-30 sec)    │    │ Cache      │
        │                 │    │ Set TTL    │
        └────────┬────────┘    │ = 30 sec   │
                 │             └─────┬──────┘
                 └─────────┬─────────┘
                           │
                       ┌───▼────────┐
                       │ Return     │
                       │ Devices    │
                       └────────────┘
```

## Device Classification Logic

```
                    Device Discovered
                           │
           ┌───────────────┼───────────────┐
           │               │               │
           ▼               ▼               ▼
      Check IP     Check Hostname   Check Service
      Pattern      Keywords         Patterns
           │               │               │
      ┌────┴───┐      ┌────┴──────┐      │
      │         │      │           │      │
    .1?   Other │      │           │      │
      │         │      │           │      │
      ▼         │      ▼           │      │
    Router      │   Contains?      │      │
      │         │   Keywords?      │      │
      │         │      │           │      │
      │         │   ┌──┴──────────┐│      │
      │         │   │             ││      │
      │         ▼   ▼ printer     ││      │
      │         Device            ││      │
      │         │                 ││      │
      │         ▼ chromecast      ││      │
      │         Smart TV          ││      │
      │         │                 ││      │
      │         ▼ camera          ││      │
      │         IP Camera         ││      │
      │         │                 ││      │
      │         ▼ alexa           ││      │
      │         Smart Speaker     ││      │
      │         │                 ││      │
      └─────────┼─────────────────┘│      │
                │                  │      │
                └──────────┬───────┘      │
                           │              │
                    ┌──────▼────────┐     │
                    │ Classification│     │
                    │ Complete      │     │
                    │ Return Type   │     │
                    └───────────────┘     │
                                          ▼
                                   Use as fallback
```

## Typical Execution Timeline

```
Timeline of Network Scan Operation:

T+0:00  User clicks "Scan Network" button
        └─ callback triggered

T+0:05  Scanner initializes
        └─ Gets local IP: 192.168.31.29

T+0:10  Determines subnet: 192.168.31.0/24

T+0:15  Attempts ARP scan (if scapy available)
        └─ Sends broadcast: "Who is on this network?"

T+3:00  Fallback method kicks in
        └─ Starts socket connection tests to 192.168.31.1-20

T+5:00  Found and testing: 192.168.31.1 (Router)

T+33:00 Completes testing all IPs

T+34:00 Classifies devices
        ├─ 192.168.31.1 = Router (IP pattern .1)
        └─ 192.168.31.29 = This Device (hostname match)

T+35:00 Gets open ports
        ├─ Tests ports 21, 22, 23... on each device
        └─ Multi-threaded for speed

T+40:00 Formats HTML table

T+41:00 Updates dashboard with results
        └─ Shows "✅ Found 2 devices"

Total Time: ~40 seconds (depends on network size & method)
UI Freezes: ~2 seconds (blocking during scan)
```

---

This architecture ensures:
- ✅ Real network scanning works
- ✅ Fallback mechanisms ensure compatibility
- ✅ Performance optimized with caching
- ✅ User gets responsive feedback
- ✅ Results accurately displayed in table

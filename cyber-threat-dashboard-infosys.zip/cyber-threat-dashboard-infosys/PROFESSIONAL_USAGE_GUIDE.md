# Professional Usage Guide - Cyber Threat Dashboard

## Quick Start

### Launch the Dashboard
```bash
cd c:\Users\KUSUMA\Desktop\cyber-threat-dashboard
python app.py
```

Then navigate to: `http://localhost:8050`

---

## Feature Overview

### 1. Live Global Threat Intelligence (Threat Map Page)

**Location:** Left sidebar navigation → "LIVE Attack Origins"

**Features:**
- 🌍 Real-time 3D globe showing threat origins
- 🎯 Attack connection visualization to SOC HQ (London)
- 📊 Live threat feed with terminal-style logging
- 📈 Real-time statistics dashboard

**How to Use:**
1. Navigate to "LIVE Attack Origins" in the left navigation
2. Watch the globe update with new threats every 5 seconds
3. Hover over threat markers for detailed information:
   - Threat type and source country
   - Severity level and timestamp
   - Current status (Active/Mitigated/Blocked)

**Color Legend:**
- 🔴 Red (#ff2e2e): Critical Threats - Immediate action required
- 🟠 Orange (#ff6b35): High Severity - Urgent attention needed
- 🟡 Yellow (#ffa500): Medium Level - Monitor closely
- 🟡 Light Yellow (#ffdd57): Low Level - Standard monitoring

---

## Professional Analytics Engine

### Real-Time Threat Statistics

The dashboard displays comprehensive metrics:

```
THREAT LEVEL STATUS
├─ CRITICAL    → 5+ critical threats detected
├─ HIGH        → 2+ critical or 8+ high threats
├─ ELEVATED    → 1+ critical or 5+ high threats
├─ MODERATE    → 8+ total threats
├─ LOW         → 1-7 threats active
└─ SECURE      → 0 active threats

RISK SCORE (0-100)
├─ 0-25   → Minimal Risk
├─ 26-50  → Moderate Risk
├─ 51-75  → High Risk
└─ 76-100 → Critical Risk

PERFORMANCE METRICS
├─ Block Rate       → % of threats successfully blocked
├─ Mitigation Rate  → % of threats successfully mitigated
└─ Detection Rate   → % of threats detected
```

### Threat Analysis

The system automatically analyzes:

**Threat Distribution**
- By Type: DDoS, Phishing, Malware, SQL Injection, Brute Force, Ransomware, Zero-Day
- By Severity: Critical, High, Medium, Low
- By Status: Active, Mitigated, Blocked, Investigating

**Geographic Analysis**
- Top threat source countries
- Regional threat concentration
- Targeting patterns analysis

**Temporal Analysis**
- Threat timeline
- Attack frequency patterns
- Peak activity hours

---

## Professional Threat Tracking

### Understanding Threat Data

Each threat displays:

```
THREAT ENTRY EXAMPLE:
═════════════════════════════════════════════════
[01] [08:30:45] DDoS [CRITICAL]
SRC: Russia → LONDON SOC | STATUS: ACTIVE
ID: a7f2c9e1
Type: Distributed Denial of Service
Severity: CRITICAL
Source: Russia (61.52°N, 105.31°E)
Timestamp: 08:30:45
Status: Active
Target: Internal Network (London, UK)
═════════════════════════════════════════════════
```

### Threat Status Meanings

| Status | Color | Meaning |
|--------|-------|---------|
| **ACTIVE** | 🔴 Red | Threat is currently ongoing |
| **MITIGATED** | 🟢 Green | Threat neutralized by security measures |
| **BLOCKED** | 🟢 Green | Threat prevented from reaching target |
| **INVESTIGATING** | 🟡 Yellow | Threat under analysis by security team |

---

## Advanced Usage

### Accessing Threat Analytics Programmatically

```python
from threat_analytics_engine import CyberThreatAnalytics, threat_analytics

# Get threat statistics
threats_data = [...]  # from global_data['live_threats']
stats = threat_analytics.get_threat_statistics(threats_data)

# Access metrics
print(f"Total Threats: {stats['total_threats']}")
print(f"Critical Count: {stats['critical_threats']}")
print(f"Block Rate: {stats['block_rate']}%")
print(f"Threat Level: {stats['threat_level']}")
print(f"Risk Score: {stats['risk_score']}/100")

# Generate threat report
report = threat_analytics.generate_threat_report(threats_data)
print(f"Report: {report}")

# Get recommendations
for rec in report['recommendations']:
    print(f"{rec['severity']}: {rec['action']}")
```

### Creating Custom Threat Markers

```python
from threat_map_globe import ThreatGlobeGenerator

# Custom threat data
custom_threat = {
    'source': 'Custom Location',
    'lat': 35.6762,
    'lon': 139.6503,
    'type': 'Custom Attack',
    'severity': 'High',
    'timestamp': '14:30:00',
    'status': 'Investigating',
    'id': 'custom_001'
}

# Generate globe with custom threat
fig, total, critical, high = ThreatGlobeGenerator.create_threat_globe([custom_threat])
```

### Integrating External Threat Intelligence

```python
# Add threat to global system
new_threat = {
    'id': 'ext_threat_001',
    'timestamp': datetime.now().strftime('%H:%M:%S'),
    'source': 'External Feed Location',
    'lat': 40.7128,
    'lon': -74.0060,
    'target': 'Internal Network',
    'type': 'External Threat Type',
    'severity': 'Critical',
    'status': 'Active'
}

# Insert into global data
global_data['live_threats'].insert(0, new_threat)

# Dashboard will automatically refresh and display
```

---

## Dashboard Navigation Guide

### Main Navigation (Left Sidebar)

| Option | Function |
|--------|----------|
| 🏠 Home | Main dashboard overview |
| 🌍 LIVE Attack Origins | Real-time global threat map with 3D globe |
| 📊 Analytics | Threat analytics and reporting |
| 🔍 Scan | Network scanning and vulnerability assessment |
| 💬 Chat | AI-powered threat intelligence chat |
| ⚙️ Settings | Dashboard configuration |

---

## Professional Monitoring Checklist

### Daily Threat Review

```
□ Check Threat Level status
  - Ensure it's not CRITICAL
  - Review any recent escalations

□ Review Top Threat Sources
  - Identify repeat threat actors
  - Update firewall rules as needed

□ Analyze Threat Types
  - Look for patterns
  - Adjust detection rules if needed

□ Check Block Rate
  - Target: >90%
  - Investigate if below threshold

□ Review Recommendations
  - Implement urgent recommendations
  - Track important security advisories
```

### Weekly Threat Report Generation

```python
from threat_analytics_engine import threat_analytics

# Generate comprehensive weekly report
weekly_threats = global_data['live_threats'][-100:]  # Last ~100 threats
report = threat_analytics.generate_threat_report(weekly_threats)

# Export or review
print(f"Week Report - Threat Level: {report['summary']['threat_level']}")
print(f"Total Threats: {report['summary']['total_threats']}")
print(f"Block Rate: {report['summary']['block_rate']}")
```

---

## Customization & Configuration

### Change Globe Center Point

Edit `threat_map_globe.py` line ~225:
```python
center=dict(lon=0, lat=20),  # Change to your SOC location
```

### Adjust Update Frequency

Edit `app.py` line ~387:
```python
dcc.Interval(id='threat-map-interval', interval=5000, n_intervals=0),
# interval in milliseconds: 5000 = 5 seconds
```

### Modify Threat Severity Display

Edit `threat_map_globe.py` severity_config:
```python
severity_config = {
    'Critical': {
        'color': '#ff2e2e',  # Change color here
        'size': 18,          # Change marker size
        'opacity': 1.0,      # Change transparency
        'line_width': 3      # Change border width
    },
    # ...
}
```

### Add Custom Threat Locations

Edit `threat_map_globe.py` THREAT_LOCATIONS:
```python
'Custom': {
    'lat': 25.0000,  # Latitude
    'lon': 55.0000,  # Longitude
    'name': 'Custom Location'
}
```

---

## Performance Tips

### For Large Threat Volumes:
1. Limit displayed threats: `threats_data[:10]` instead of all
2. Increase update interval: 10000 (10 seconds) instead of 5000
3. Enable data caching: Reuse previous figures if no new threats
4. Disable hover effects on map for faster rendering

### For High Latency Networks:
1. Reduce globe complexity: Use simpler projection
2. Cache threat data locally
3. Compress visualization data
4. Use WebGL rendering (if available)

---

## Troubleshooting Guide

### Problem: Callback Error
**Solution:**
```bash
1. Clear browser cache (Ctrl+Shift+Delete)
2. Restart dashboard
3. Check console errors (F12)
4. Verify Plotly version: pip show plotly
```

### Problem: Threats Not Updating
**Solution:**
```bash
1. Check if background thread is running
2. Verify threat data generation in app.py
3. Check browser network tab for failed requests
4. Verify interval component exists in HTML
```

### Problem: Globe Not Displaying
**Solution:**
```bash
1. Check browser compatibility (Chrome/Firefox/Edge)
2. Verify Plotly library is installed
3. Check mapbox token (if using mapbox style)
4. Verify GeoJSON data availability
```

### Problem: Performance Issues
**Solution:**
1. Reduce number of threats displayed
2. Increase update interval
3. Clear browser cache
4. Disable animations
5. Use simpler map projection

---

## Best Practices

### ✅ Do:
- Review threat reports daily
- Monitor threat level status continuously
- Act on urgent recommendations
- Keep firewall rules updated
- Document threat incidents
- Test recovery procedures

### ❌ Don't:
- Ignore CRITICAL level threats
- Disable automated protections
- Share threat data externally
- Leave dashboard unattended during incidents
- Forget to update threat definitions
- Ignore block rate drops

---

## Support & Maintenance

### Regular Maintenance Tasks

**Weekly:**
- Clear old threat logs (>1000 entries)
- Update threat detection rules
- Review security recommendations

**Monthly:**
- Generate comprehensive threat reports
- Analyze threat trends
- Update firewall rules
- Test alerting system

**Quarterly:**
- Security audit of dashboard access
- Update threat definitions
- Review and update SOC procedures
- Test incident response procedures

---

## Contact & Support

For issues or questions:
1. Check the ENHANCEMENTS.md file
2. Review console output for error messages
3. Check Plotly/Dash documentation
4. Review threat_analytics_engine.py source code

---

**Version:** 2.0.0  
**Last Updated:** February 8, 2026  
**Maintained By:** Cyber Security Team

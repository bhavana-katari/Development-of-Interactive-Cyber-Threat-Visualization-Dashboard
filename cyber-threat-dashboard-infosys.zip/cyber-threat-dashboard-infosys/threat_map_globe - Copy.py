# Professional Cyber Threat Globe Visualization
# Enhanced with dynamic threat detection and professional styling

import plotly.graph_objects as go
import pandas as pd
from datetime import datetime
import random


class ThreatGlobeGenerator:
    """Professional threat globe with dynamic rendering"""
    
    # Preset threat locations globally distributed
    THREAT_LOCATIONS = {
        'USA': {'lat': 37.0902, 'lon': -95.7129, 'name': 'United States'},
        'China': {'lat': 35.8617, 'lon': 104.1954, 'name': 'China'},
        'Russia': {'lat': 61.5240, 'lon': 105.3188, 'name': 'Russia'},
        'Germany': {'lat': 51.1657, 'lon': 10.4515, 'name': 'Germany'},
        'UK': {'lat': 55.3781, 'lon': -3.4360, 'name': 'United Kingdom'},
        'India': {'lat': 20.5937, 'lon': 78.9629, 'name': 'India'},
        'Brazil': {'lat': -14.2350, 'lon': -51.9253, 'name': 'Brazil'},
        'Japan': {'lat': 36.2048, 'lon': 138.2529, 'name': 'Japan'},
        'Australia': {'lat': -25.2744, 'lon': 133.7751, 'name': 'Australia'},
        'Canada': {'lat': 56.1304, 'lon': -106.3468, 'name': 'Canada'},
        'France': {'lat': 46.2276, 'lon': 2.2137, 'name': 'France'},
        'Vietnam': {'lat': 14.0583, 'lon': 108.2772, 'name': 'Vietnam'},
        'Norway': {'lat': 60.4720, 'lon': 8.4689, 'name': 'Norway'},
        'Malaysia': {'lat': 4.2105, 'lon': 101.9758, 'name': 'Malaysia'},
        'Singapore': {'lat': 1.3521, 'lon': 103.8198, 'name': 'Singapore'},
        'Israel': {'lat': 31.0461, 'lon': 34.8516, 'name': 'Israel'},
        'South Korea': {'lat': 35.9078, 'lon': 127.7669, 'name': 'South Korea'},
        'Netherlands': {'lat': 52.1326, 'lon': 5.2913, 'name': 'Netherlands'},
        'UAE': {'lat': 23.4241, 'lon': 53.8478, 'name': 'UAE'},
        'Mexico': {'lat': 23.6345, 'lon': -102.5528, 'name': 'Mexico'},
    }
    
    # Defense hub (London SOC)
    DEFENSE_HUB = {
        'lat': 51.5074,
        'lon': -0.1278,
        'name': 'SOC HQ - LONDON',
        'status': 'OPERATIONAL',
        'protection': 'ACTIVE'
    }
    
    @staticmethod
    def create_threat_globe(threats_data):
        """Create a professional 3D globe with threat markers and connections"""
        
        if not threats_data:
            threats_data = []
        
        # Initialize figure
        fig = go.Figure()
        
        # Add globe background (invisible base for sphere)
        fig.add_trace(go.Scattergeo(
            lon=[0],
            lat=[0],
            mode='markers',
            marker=dict(size=0),
            showlegend=False,
            hoverinfo='skip'
        ))
        
        # Process and organize threats by severity
        threat_by_severity = {
            'Critical': [],
            'High': [],
            'Medium': [],
            'Low': []
        }
        
        # Fill threat categories
        for threat in threats_data:
            severity = threat.get('severity', 'Low')
            if severity in threat_by_severity:
                threat_by_severity[severity].append(threat)
        
        # Color mapping and sizing
        severity_config = {
            'Critical': {
                'color': '#ff2e2e',
                'size': 18,
                'opacity': 1.0,
                'line_width': 3
            },
            'High': {
                'color': '#ff6b35',
                'size': 14,
                'opacity': 0.95,
                'line_width': 2
            },
            'Medium': {
                'color': '#ffa500',
                'size': 10,
                'opacity': 0.85,
                'line_width': 1.5
            },
            'Low': {
                'color': '#ffdd57',
                'size': 8,
                'opacity': 0.7,
                'line_width': 1
            }
        }
        
        # Add attack connection lines from threats to defense hub
        for severity in ['Critical', 'High', 'Medium', 'Low']:
            for threat in threat_by_severity[severity][:10]:  # Limit connections for performance
                config = severity_config[severity]
                
                # Connection line
                fig.add_trace(go.Scattergeo(
                    lon=[threat.get('lon'), ThreatGlobeGenerator.DEFENSE_HUB['lon']],
                    lat=[threat.get('lat'), ThreatGlobeGenerator.DEFENSE_HUB['lat']],
                    mode='lines',
                    line=dict(
                        width=config['line_width'],
                        color=config['color']
                    ),
                    hoverinfo='skip',
                    showlegend=False,
                    opacity=config['opacity'] * 0.6
                ))
        
        # Add threat markers (Grouped by severity for performance and correct hover handling)
        for severity in ['Low', 'Medium', 'High', 'Critical']:
            config = severity_config[severity]
            severity_threats = threat_by_severity[severity]
            
            if not severity_threats:
                continue

            lons = [t.get('lon') for t in severity_threats]
            lats = [t.get('lat') for t in severity_threats]
            
            hover_texts = []
            for t in severity_threats:
                # Use new fields if available
                source_val = t.get('country', t.get('source', 'Unknown'))
                ip_val = t.get('source_ip', '')
                display_name = f"{source_val} ({ip_val})" if ip_val else source_val
                
                h_text = (
                    f"<b>{display_name}</b><br>" +
                    f"Type: <b>{t.get('type', 'Unknown')}</b><br>" +
                    f"Severity: <b style='color:{config['color']}'>{severity}</b><br>" +
                    f"Time: {t.get('timestamp', 'N/A')}<br>" +
                    f"Status: <b>{t.get('status', 'Active')}</b><br>" +
                    f"Lat: {t.get('lat', 0):.2f}°, Lon: {t.get('lon', 0):.2f}°"
                )
                hover_texts.append(h_text)
            
            fig.add_trace(go.Scattergeo(
                lon=lons,
                lat=lats,
                mode='markers',
                marker=dict(
                    size=config['size'],
                    color=config['color'],
                    opacity=config['opacity'],
                    line=dict(
                        width=config['line_width'],
                        color='white'
                    ),
                    sizemode='diameter'
                ),
                text=hover_texts,
                hovertemplate='%{text}<extra></extra>',
                showlegend=True, # Show in legend now that it's grouped
                name=f"Threat: {severity}"
            ))
        
        # Add defense hub with glow effect (using size variation)
        for glow_size in [45, 35]:
            fig.add_trace(go.Scattergeo(
                lon=[ThreatGlobeGenerator.DEFENSE_HUB['lon']],
                lat=[ThreatGlobeGenerator.DEFENSE_HUB['lat']],
                mode='markers',
                marker=dict(
                    size=glow_size,
                    color='#00ff88' if glow_size == 35 else 'rgba(0,255,136,0.2)',
                    opacity=1.0 if glow_size == 35 else 0.3,
                    line=dict(
                        width=2 if glow_size == 35 else 0,
                        color='#00ff88'
                    ),
                    sizemode='diameter'
                ),
                hovertemplate=f"<b>{ThreatGlobeGenerator.DEFENSE_HUB['name']}</b><br>" +
                              f"Status: <b style='color:#00ff88'>{ThreatGlobeGenerator.DEFENSE_HUB['status']}</b><br>" +
                              f"Protection: <b style='color:#00ff88'>{ThreatGlobeGenerator.DEFENSE_HUB['protection']}</b>" +
                              "<extra></extra>",
                showlegend=False,
                name='SOC HQ'
            ))
        
        # Calculate statistics
        total_threats = len(threats_data)
        critical_count = len(threat_by_severity.get('Critical', []))
        high_count = len(threat_by_severity.get('High', []))
        
        # Update layout with professional styling
        fig.update_layout(
            title={
                'text': '<b>🌍 GLOBAL CYBER THREAT INTELLIGENCE</b><br><sub>Real-time Dynamic Threat Detection & Geolocation</sub>',
                'x': 0.5,
                'xanchor': 'center',
                'font': {'color': 'white', 'size': 20}
            },
            showlegend=False,
            geo=dict(
                scope='world',
                projection_type='natural earth',
                showland=True,
                landcolor='rgb(20, 20, 30)',
                showocean=True,
                oceancolor='rgb(10, 10, 20)',
                showcountries=True,
                countrycolor='rgb(50, 50, 60)',
                showlakes=True,
                lakecolor='rgb(15, 15, 25)',
                bgcolor='rgba(0, 0, 0, 0.8)',
                coastlinecolor='rgb(60, 60, 70)',
                center=dict(lon=0, lat=20),
                visible=True
            ),
            paper_bgcolor='#0a0a0a',
            plot_bgcolor='rgba(0, 0, 0, 0.3)',
            font=dict(
                family='Courier New, monospace',
                size=11,
                color='#00ff88'
            ),
            height=700,
            margin=dict(l=0, r=0, t=80, b=0),
            hovermode='closest',
            hoverlabel=dict(
                bgcolor='rgba(10, 10, 20, 0.95)',
                font=dict(family='monospace', size=12, color='white'),
                bordercolor='#00ff88'
            )
        )
        
        return fig, total_threats, critical_count, high_count


def create_threat_feed_items(threats_data):
    """Create formatted threat feed list items"""
    from dash import html
    
    feed_items = []
    
    if not threats_data:
        feed_items = [html.Div([
            html.P("● INITIALIZING GLOBAL SENSORS", 
                  style={'fontFamily': 'monospace', 'fontSize': '12px', 'color': '#00ff88', 'margin': '5px'}),
            html.P("● SCANNING INTERNATIONAL TRAFFIC", 
                  style={'fontFamily': 'monospace', 'fontSize': '11px', 'color': '#888', 'margin': '5px'})
        ])]
        return feed_items
    
    # Add header with statistics
    critical_count = len([t for t in threats_data if t.get('severity') == 'Critical'])
    high_count = len([t for t in threats_data if t.get('severity') == 'High'])
    total_count = len(threats_data)
    
    header_text = (
        f"● THREATS DETECTED: {total_count} | "
        f"CRITICAL: {critical_count} | HIGH: {high_count}"
    )
    
    feed_items.append(html.Div([
        html.P(header_text, 
              style={'fontFamily': 'monospace', 'fontSize': '11px', 'color': '#00ff88', 'margin': '5px', 'fontWeight': 'bold'}),
        html.Hr(style={'margin': '5px 0', 'borderColor': '#333', 'borderWidth': '0.5px'})
    ], style={'padding': '8px', 'backgroundColor': 'rgba(0,255,136,0.05)', 'borderBottom': '1px solid #333'}))
    
    # Add threat entries (limit to 12)
    for idx, threat in enumerate(threats_data[:12]):
        severity = threat.get('severity', 'Low')
        severity_colors = {
            'Critical': '#ff2e2e',
            'High': '#ff6b35',
            'Medium': '#ffa500',
            'Low': '#ffdd57'
        }
        status = threat.get('status', 'Active')
        status_color = '#00ff88' if status == 'Mitigated' else '#ff2e2e'
        color = severity_colors.get(severity, '#aaa')
        
        threat_entry = html.Div([
            html.Div([
                html.Span(f"[{idx+1:02d}]", style={'color': '#666', 'fontFamily': 'monospace', 'fontSize': '9px', 'width': '30px'}),
                html.Span(f"{threat.get('timestamp', 'N/A')}", style={'color': '#888', 'fontFamily': 'monospace', 'fontSize': '9px', 'width': '70px'}),
                html.Span(f"{threat.get('type', 'Unknown').upper()}", 
                         style={'color': color, 'fontWeight': 'bold', 'fontFamily': 'monospace', 'fontSize': '10px', 'marginLeft': '5px', 'flex': 1}),
                html.Span(f"[{severity.upper()}]", 
                         style={'color': color, 'fontFamily': 'monospace', 'fontSize': '9px', 'fontWeight': 'bold', 'marginLeft': '5px'}),
            ], style={'display': 'flex', 'alignItems': 'center', 'marginBottom': '3px'}),
            html.Div([
                html.Span(f"SRC: {threat.get('source_ip', threat.get('source', 'Unknown'))}", style={'color': '#aaa', 'fontSize': '9px', 'fontFamily': 'monospace'}),
                html.Span(" | ", style={'color': '#555', 'fontSize': '9px', 'marginX': '3px'}),
                html.Span(f"{threat.get('country', 'N/A')}", style={'color': '#00ff88', 'fontSize': '9px', 'fontFamily': 'monospace'}),
                html.Span(" | ", style={'color': '#555', 'fontSize': '9px', 'marginX': '3px'}),
                html.Span(f"STATUS: {status.upper()}", 
                         style={'color': status_color, 'fontSize': '9px', 'fontWeight': 'bold', 'fontFamily': 'monospace'}),
            ], style={'fontSize': '9px', 'marginBottom': '4px'}),
            html.Hr(style={'margin': '3px 0', 'borderColor': '#222', 'borderWidth': '0.5px'})
        ], style={
            'padding': '8px',
            'borderLeft': f'3px solid {color}',
            'paddingLeft': '10px',
            'marginBottom': '3px'
        })
        
        feed_items.append(threat_entry)
    
    return feed_items
